# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'playerMyHdtB.ui'
##
## Created by: Qt User Interface Compiler version 6.2.4
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QLabel,
    QMainWindow, QMenuBar, QPushButton, QSizePolicy,
    QSlider, QSpacerItem, QToolBar, QVBoxLayout,
    QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(759, 547)
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.widget = QWidget(self.centralwidget)
        self.widget.setObjectName(u"widget")
        self.horizontalLayout_3 = QHBoxLayout(self.widget)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.widget_3 = QWidget(self.widget)
        self.widget_3.setObjectName(u"widget_3")
        self.widget_3.setMaximumSize(QSize(53, 16777215))
        self.verticalLayout_4 = QVBoxLayout(self.widget_3)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.last_btn = QPushButton(self.widget_3)
        self.last_btn.setObjectName(u"last_btn")
        self.last_btn.setMinimumSize(QSize(35, 35))
        self.last_btn.setMaximumSize(QSize(35, 35))
        icon = QIcon()
        icon.addFile(u"/home/shida/projects/python/Qt_Apps/music_player/icons/arrow-left-circle.svg", QSize(), QIcon.Normal, QIcon.On)
        self.last_btn.setIcon(icon)
        self.last_btn.setIconSize(QSize(32, 32))

        self.verticalLayout_4.addWidget(self.last_btn)


        self.horizontalLayout_3.addWidget(self.widget_3)

        self.frame_2 = QFrame(self.widget)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMinimumSize(QSize(100, 0))
        self.frame_2.setStyleSheet(u"QFrame{\n"
"	border:None;\n"
"}")
        self.frame_2.setFrameShape(QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_2)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.widget_5 = QWidget(self.frame_2)
        self.widget_5.setObjectName(u"widget_5")
        self.widget_5.setMinimumSize(QSize(0, 350))
        self.verticalLayout_3 = QVBoxLayout(self.widget_5)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.image_label = QLabel(self.widget_5)
        self.image_label.setObjectName(u"image_label")

        self.verticalLayout_3.addWidget(self.image_label, 0, Qt.AlignHCenter)

        self.title_label = QLabel(self.widget_5)
        self.title_label.setObjectName(u"title_label")
        font = QFont()
        font.setPointSize(10)
        self.title_label.setFont(font)

        self.verticalLayout_3.addWidget(self.title_label, 0, Qt.AlignHCenter|Qt.AlignBottom)


        self.verticalLayout_2.addWidget(self.widget_5)

        self.verticalSpacer = QSpacerItem(20, 40, QSizePolicy.Minimum, QSizePolicy.Expanding)

        self.verticalLayout_2.addItem(self.verticalSpacer)

        self.frame = QFrame(self.frame_2)
        self.frame.setObjectName(u"frame")
        self.frame.setMaximumSize(QSize(1000000, 16777215))
        self.frame.setStyleSheet(u"QFrame{\n"
"	border:None;\n"
"}")
        self.frame.setFrameShape(QFrame.StyledPanel)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.frame)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.play_btn = QPushButton(self.frame)
        self.play_btn.setObjectName(u"play_btn")
        self.play_btn.setMinimumSize(QSize(35, 35))
        self.play_btn.setMaximumSize(QSize(35, 35))
        self.play_btn.setStyleSheet(u"background-color: rgb(0, 0, 127);")
        icon1 = QIcon()
        icon1.addFile(u"/home/shida/projects/python/Qt_Apps/music_player/icons/play-circle.svg", QSize(), QIcon.Normal, QIcon.On)
        self.play_btn.setIcon(icon1)
        self.play_btn.setIconSize(QSize(32, 32))

        self.horizontalLayout_4.addWidget(self.play_btn, 0, Qt.AlignRight)

        self.pause_btn = QPushButton(self.frame)
        self.pause_btn.setObjectName(u"pause_btn")
        self.pause_btn.setMinimumSize(QSize(35, 35))
        self.pause_btn.setMaximumSize(QSize(35, 35))
        self.pause_btn.setStyleSheet(u"background-color: rgb(0, 0, 127);")
        icon2 = QIcon()
        icon2.addFile(u"/home/shida/projects/python/Qt_Apps/music_player/icons/pause-circle.svg", QSize(), QIcon.Normal, QIcon.On)
        self.pause_btn.setIcon(icon2)
        self.pause_btn.setIconSize(QSize(32, 32))

        self.horizontalLayout_4.addWidget(self.pause_btn, 0, Qt.AlignRight)

        self.time_slider = QSlider(self.frame)
        self.time_slider.setObjectName(u"time_slider")
        self.time_slider.setMaximumSize(QSize(16777215, 16777215))
        self.time_slider.setOrientation(Qt.Horizontal)

        self.horizontalLayout_4.addWidget(self.time_slider)

        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setEnabled(False)
        self.label.setMinimumSize(QSize(20, 0))

        self.horizontalLayout_4.addWidget(self.label)

        self.volume_btn = QPushButton(self.frame)
        self.volume_btn.setObjectName(u"volume_btn")
        self.volume_btn.setEnabled(True)
        self.volume_btn.setMinimumSize(QSize(32, 32))
        self.volume_btn.setMaximumSize(QSize(32, 32))
        self.volume_btn.setStyleSheet(u"background-color: rgb(0, 0, 127);")
        icon3 = QIcon()
        icon3.addFile(u"/home/shida/projects/python/Qt_Apps/music_player/icons/volume-2.svg", QSize(), QIcon.Normal, QIcon.On)
        self.volume_btn.setIcon(icon3)
        self.volume_btn.setIconSize(QSize(32, 32))

        self.horizontalLayout_4.addWidget(self.volume_btn, 0, Qt.AlignRight)


        self.verticalLayout_2.addWidget(self.frame)


        self.horizontalLayout_3.addWidget(self.frame_2)

        self.widget_2 = QWidget(self.widget)
        self.widget_2.setObjectName(u"widget_2")
        self.widget_2.setEnabled(True)
        self.widget_2.setMaximumSize(QSize(53, 16777215))
        self.horizontalLayout = QHBoxLayout(self.widget_2)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.next_btn = QPushButton(self.widget_2)
        self.next_btn.setObjectName(u"next_btn")
        self.next_btn.setMinimumSize(QSize(35, 35))
        self.next_btn.setMaximumSize(QSize(35, 35))
        icon4 = QIcon()
        icon4.addFile(u"/home/shida/projects/python/Qt_Apps/music_player/icons/arrow-right-circle.svg", QSize(), QIcon.Normal, QIcon.On)
        self.next_btn.setIcon(icon4)
        self.next_btn.setIconSize(QSize(32, 32))

        self.horizontalLayout.addWidget(self.next_btn)


        self.horizontalLayout_3.addWidget(self.widget_2)


        self.verticalLayout.addWidget(self.widget)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 759, 19))
        MainWindow.setMenuBar(self.menubar)
        self.toolBar = QToolBar(MainWindow)
        self.toolBar.setObjectName(u"toolBar")
        MainWindow.addToolBar(Qt.TopToolBarArea, self.toolBar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.last_btn.setText("")
        self.image_label.setText("")
        self.title_label.setText("")
        self.play_btn.setText("")
        self.pause_btn.setText("")
        self.label.setText("")
        self.volume_btn.setText("")
        self.next_btn.setText("")
        self.toolBar.setWindowTitle(QCoreApplication.translate("MainWindow", u"toolBar", None))
    # retranslateUi

