from PySide6.QtWidgets import *
from PySide6.QtGui import *
from PySide6.QtCore import *
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from ui_player import *
import sys
import os
import eyed3 as eye


class logic(QMainWindow):
    def __init__(self):
        super(logic, self).__init__()

        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        action_open = QAction(self.ui.toolBar)
        open_icon = QIcon()
        open_icon.addFile("/home/shida/projects/python/Qt_Apps/music_player/icons/folder.svg", QSize(), QIcon.Normal, QIcon.Off)
        action_open.setIcon(open_icon)
        action_open.triggered.connect(self.open_file)
        self.ui.toolBar.addAction(action_open)

        self.volume = 30
        
        self.player = QMediaPlayer()
        self.audio = QAudioOutput()
        self.player.setAudioOutput(self.audio)
        self.audio.setVolume(self.volume)

        self.path = None
        self.music_path = None

        self.index = 0

        self.ui.play_btn.setEnabled(True)  
        self.ui.pause_btn.setEnabled(True)          

        self.connect()

        self.show()
    
    def connect(self):
        #connect buttons
        self.ui.next_btn.clicked.connect(self.next_) 
        self.ui.last_btn.clicked.connect(self.last)
        self.ui.play_btn.clicked.connect(self.play)
        self.ui.pause_btn.clicked.connect(self.pause)
        self.ui.volume_btn.clicked.connect(self.volume_changed)

        #connect signal 
        self.player.positionChanged.connect(self.position_changed)
        self.player.durationChanged.connect(self.duration_changed)

        #connect sliders
        self.ui.time_slider.sliderMoved.connect(self.time_slider_changed)
        

    def set_Image(self):
        t_label = self.ui.title_label
        img_label = self.ui.image_label 

        file = eye.load(self.music_path)
        images = file.tag.images

        try:
            with open("/home/shida/projects/python/Qt_Apps/music_player/cover.jpg", "wb+") as file:
                file.write(images[0].image_data)
        except IndexError:
            pass
        
        img = QPixmap("/home/shida/projects/python/Qt_Apps/music_player/cover.jpg")

        #put a picture on label
        img_label.setPixmap(img)
        t_label.setText(self.music_path)            


    def open_file(self): #set music: 
        file_name = QFileDialog.getOpenFileName(self, "Choose a file", "/home/shida/Music")
        self.path = os.path.dirname(file_name[0])
        
        file, extention = os.path.splitext(file_name[0])

        for i in range(len(os.listdir(self.path))):
            if file_name[0] == self.path + "/" + os.listdir(self.path)[i]:
                self.index = i
                break

        self.music_path = self.path + "/" + os.listdir(self.path)[self.index]

        if extention in(".mp3, .waw"):
            self.player.setSource(QUrl.fromLocalFile(self.music_path)) 
            #set image
            self.set_Image()
            #music is found
            self.player.play()

    def next_(self):
            try:
                self.index += 1

                file, extention = os.path.splitext(self.music_path)

                self.music_path = self.path + "/" + os.listdir(self.path)[self.index]

                if extention in(".mp3, .waw"):                
                    self.player.setSource(QUrl.fromLocalFile(self.music_path))
                    #set image
                    self.set_Image()
                    #music is found                
                    self.player.play()                      

            except IndexError:
                print("index error in next_................")
                self.index = 0
                self.music_path = self.path + "/" + os.listdir(self.path)[self.index]

                if extention in(".mp3, .waw"): 
                    self.player.setSource(QUrl.fromLocalFile(self.music_path)) 
                    #set image
                    self.set_Image()
                    #music is found
                    self.player.play()


    def last(self):
            try:
                self.index -= 1

                file, extention = os.path.splitext(self.music_path)

                self.music_path = self.path + "/" + os.listdir(self.path)[self.index]


                if self.index != -1:
                    if extention in(".mp3, .waw"):                
                        self.player.setSource(QUrl.fromLocalFile(self.music_path))
                        #set image
                        self.set_Image()
                        #music is found                
                        self.player.play()
                
                else:
                    self.index = len(os.listdir(self.path))-1
                    
                    self.music_path = self.path + "/" + os.listdir(self.path)[self.index] 

                    if extention in(".mp3, .waw"):                
                        self.player.setSource(QUrl.fromLocalFile(self.music_path))
                        #set image
                        self.set_Image()
                        #music is found                
                        self.player.play()
                                
            except IndexError:
                pass

    def play(self):
        self.player.play()

    def pause(self):
        self.player.pause()
        

    def position_changed(self, position):
        self.ui.time_slider.setMaximum(self.player.duration())

        self.ui.time_slider.setValue(position)

    def duration_changed(self, duration):
        self.ui.time_slider.setRange(0, duration)
        

    def volume_changed(self):
        if self.volume != 0:
            self.volume = 0
            self.audio.setVolume(self.volume)
        else:
            self.volume = 30
            self.audio.setVolume(self.volume)        


    def time_slider_changed(self, position):    
        self.player.setPosition(position)

    

if __name__ == "__main__":
    app = QApplication(sys.argv)
    log = logic()
    sys.exit(app.exec())